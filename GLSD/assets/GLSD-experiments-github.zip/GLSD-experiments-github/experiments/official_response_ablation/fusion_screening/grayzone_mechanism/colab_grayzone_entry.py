"""Use the existing Colab Python and pandas adapter, in an isolated subprocess."""
import colab_p8_entry
from run_grayzone import main

if __name__ == '__main__':
    main()
