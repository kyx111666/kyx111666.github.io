import colab_p8_entry
from run_mechanism import main
if __name__=='__main__':main()
