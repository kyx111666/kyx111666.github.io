"""Launch with the same interpreter and pandas shim as previous Colab work."""
import colab_p8_entry
from run_reference_residual import main

if __name__ == '__main__':
    main()
