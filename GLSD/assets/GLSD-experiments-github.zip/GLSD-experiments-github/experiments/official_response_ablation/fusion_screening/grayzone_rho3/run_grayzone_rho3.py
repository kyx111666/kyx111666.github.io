"""Canonical rho3 runner name; implementation lives in run_grayzone.py."""
from run_grayzone import *  # noqa: F401,F403
from run_grayzone import main


if __name__ == '__main__':
    main()
