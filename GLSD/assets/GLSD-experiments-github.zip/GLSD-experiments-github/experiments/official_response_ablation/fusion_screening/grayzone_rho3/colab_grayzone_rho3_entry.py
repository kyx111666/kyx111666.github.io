"""Colab entry point for the rho3 package."""
import colab_p8_entry  # noqa: F401
from run_grayzone_rho3 import main


if __name__ == '__main__':
    main()
