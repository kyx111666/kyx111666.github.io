import colab_p8_entry
from run_eta_gm import main

if __name__ == '__main__':
    main()
