"""Same Colab interpreter and pandas adapter as completed experiments."""
import colab_p8_entry
from run_joint_gm import main

if __name__ == '__main__':
    main()
