"""Reuse the same pandas compatibility adapter and Python environment."""
import colab_p8_entry
from run_p8_one_to_one import main

if __name__ == '__main__':
    main()
