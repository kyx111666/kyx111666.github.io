import colab_p8_entry  # Existing pandas compatibility, same interpreter.
from run_p8_threshold_control import main
if __name__ == '__main__':
    main()
