"""Use the same pandas adapter and configured author checkout as the ETA run."""
import colab_p8_entry
from run_reliable_local_union import main

if __name__ == '__main__':
    main()
