"""GL-Decoder-v2: a reconstructed, reproducible training-free decoder."""

from .decoder import GLConfig, GLDecoder

__all__ = ["GLConfig", "GLDecoder"]
