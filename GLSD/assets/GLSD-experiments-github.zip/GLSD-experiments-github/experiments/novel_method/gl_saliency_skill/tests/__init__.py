"""Regression tests for FINAL-GL-SKILL."""
