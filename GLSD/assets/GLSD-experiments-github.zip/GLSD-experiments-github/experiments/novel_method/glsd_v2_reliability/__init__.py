"""Exploratory alignment-reliability extension; GLSD-v1 remains unchanged."""

