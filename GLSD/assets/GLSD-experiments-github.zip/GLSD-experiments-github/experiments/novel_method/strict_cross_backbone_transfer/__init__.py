"""Strict source-only configuration transfer experiment."""
