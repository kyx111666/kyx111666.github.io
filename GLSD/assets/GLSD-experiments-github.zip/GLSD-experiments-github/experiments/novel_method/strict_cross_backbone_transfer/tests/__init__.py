"""Tests for the strict transfer experiment."""
