"""Exact matched-budget reviewer control experiment."""
